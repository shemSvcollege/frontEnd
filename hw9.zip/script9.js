/*targil2*/

function avg(arr) {
    //debugger;
    tot = 0;
    for (var i = 0; i < arr.length; i++) {
        tot += arr[i];
    }
    avg = tot / arr.length;
    console.log(avg);
}

avg([10, 15, 20, 25, 20]);

/*targil3*/

function biggerToSmaller(arr) {
    //debugger;
    var newArr = [];
    arr.sort(sortNumber);
    for (var j = arr.length - 1; j >= 0; j--) {
        newArr.push(arr[j]);

    }
    console.log(newArr);

}

function sortNumber(a, b) {
    return a - b;
}

biggerToSmaller([10, 15, 2, 30, 35, 41, 7]);

/*targil4*/

function same(arr1, arr2) {
    var newArr = [];
    //debugger;
    arr1.sort(sortNumber);
    for (var i = 0; i < arr1.length; i++) {
        for (var j = 0; j < arr2.length; j++) {
            if (arr1[i] == arr2[j]) {
                newArr.push(arr1[i]);
                if (newArr.length > 1 && newArr[newArr.length - 1] == newArr[newArr.length - 2]) {
                    newArr.pop();
                }

            }
        }
    }
    console.log(newArr);

}

same([1, 2, 1, 2, 1], [2, 2, 2, 1, 3, 1, 2]);

/*targil5*/

function capLetter(mat) {
    var count = 0;
    //debugger;
    for (var row = 0; row < mat.length; row++) {
        for (var col = 0; col < mat[row].length; col++) {
            if (mat[row][col] >= "A" && mat[row][col] <= "Z") {
                count++;
            }
        }
    }
    console.log("numbers of capital letter: " + count);
}

capLetter([["a", "f", "E", "8"], ["1", "D", "L"], ["P", "0", "v"]]);
/*targil6*/

function func(matrix) {
    var count = 0;
    var I = 0;
    //debugger;
    for (var row = 0; row < matrix.length; row++) {
        for (var col = 0; col < matrix[row].length; col++) {
            if (matrix[row][col] == 1) {
                count++;
            }
        }
        if (count == 1) {
            I++;
        }
        count = 0;
    }
    console.log("numbers of I: " + I);
}

func([[0, 0, 0, 1, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 1, 1, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1]])

/*targil7*/

function func2(mat2){
    //debugger;
    for(var row = 0; row < mat2.length; row++){
        var count = 0;
        for(var col=0; col<mat2[row].length; col++){
            for(var i=1; i<=9; i++){
                if((i-1) != col && mat2[row][i-1] == mat2[row][col]){
                    console.log("wrong matrix");
                    return false;                
                }
                if(i == mat2[row][col]){
                    count++;
                }
            }
        }
        if(count!=9){
            console.log("wrong matrix");
            return false;
        }
    }
    console.log("right matrix");
    
}

func2([[1,2,3,4,5,6,7,8,9],[5,8,7,6,1,2,4,3,9],[8,5,7,6,1,2,4,3,9]])

/*targil1*/

function func(mat) {
    //debugger;
    var main = 0;
    var secondary = 0;
    for (var row = 0; row < mat.length; row++) {
        for (var col = 0; col < mat[row].length; col++) {
            if (row == col) {
                main += mat[row][col];
            }

        }
    }
    for (var row = 0, col = mat[row].length-1; row < mat.length; row++ , col--) {
        secondary += mat[row][col];

    }
    if(secondary>main){
        console.log(secondary);
    }
    else{
        console.log(main);
    }
}

func([[1,2,3],[4,5,6],[7,8,9]]);