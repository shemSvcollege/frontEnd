/*targil1*/

function polindrom() {
    //debugger;
    var numb = parseInt(document.getElementById("pol").value);
    var count = 0;
    for (var i = 0; i <= numb; i++) {
        if (numb % i == 0) {
            count++;
        }
    }
    if (count == 2) {
        alert("true");
        document.getElementById("pol").value = "";
        return true;
    }
    else {
        alert("false");
        document.getElementById("pol").value = "";
        return false;
    }
}

/*targil2*/

function email() {
    //debugger;
    var mail = document.getElementById("email").value;
    var end = mail.slice(mail.indexOf(".") + 1, mail.length + 1);
    var strdl = mail.slice(mail.indexOf("@") + 1, mail.indexOf("."));
    var flag = true;
    for (var i = mail.indexOf(".") + 1; i < mail.length; i++) {
        if (mail.charAt(i) >= "0" && mail.charAt(i) <= "9") {
            flag = false;
        }
    }
    if (mail.indexOf("@") > 1 && mail.length >= 5 && mail.indexOf("@") < mail.indexOf(".") && end.length > 2 && strdl.length > 1 && flag) {
        alert("correct");
        document.getElementById("email").value = "";
    }
    else {
        alert("wrong email try again");
        document.getElementById("email").value = "";
    }
}

/*targil3*/

function triangel() {
    //debugger;
    var numb = parseInt(document.getElementById("draw").value);
    var raw = "";
    var count = numb;
    for (var j = 0; j < numb; j++) {
        if (j > 0) {
            for (var move = j; move > 0; move--) {
                raw += " ";
            }
        }
        for (var i = 0; i < count; i++) {
            raw += "* ";
        }
        count--;
        raw += "\n";
    }
    console.log(raw);
    document.getElementById("draw").value = "";
}

/*targil4*/

function date() {
    var date = document.getElementById("date").value;
    var addDays = parseInt(document.getElementById("days").value);
    document.getElementById("newDate").value = "";
    var count = 0;
    //debugger;
    for (var i = 0; i < date.length; i++) {
        if (date.charAt(i) == ".") {
            count++;
            var point = i;
        }
    }


    var day = date.slice(0, date.indexOf("."));
    var month = date.slice(day.length + 1, point);
    var year = date.slice(point + 1, date.length);

    if (count != 2 || day.length != 2 || month.length != 2 || year.length != 4 || parseInt(day) > 30 || parseInt(month) > 12) {
        alert("wrong date try again");
        document.getElementById("date").value = "";
        document.getElementById("days").value = "";
        return false;
    }
    else {
        //debugger;
        document.getElementById("date").value = "";
        document.getElementById("days").value = "";
    }
    //debugger;

    var day = parseInt(day);
    var month = parseInt(month);
    var year = parseInt(year);

    day = day + addDays;
    if (day >= 30 && day <= 60) {
        day = day - 30;
        month = month + 1;
        if (month > 12) {
            month = 1;
            year = year + 1;
        }
    }

    else if(day>60) {
        var temp = day / 30;
        var addMonth = temp;
        addMonth = parseInt(addMonth.toFixed(0));
        if(addMonth > temp){
            addMonth = addMonth - 1;
        }

        day = day - addMonth*30;
        month = addMonth + month;
        if (month > 12) {
            var addYear = 0;
            while (month > 12) {
                addYear++;
                month = month - 12;
            }
            year = year + addYear;
        }
    }
    
    var newDate = day + "." + month + "." + year;
    document.getElementById("newDate").value = newDate;

}

